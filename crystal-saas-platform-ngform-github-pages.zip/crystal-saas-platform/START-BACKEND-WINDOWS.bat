@echo off
setlocal
cd /d "%~dp0backend"
echo Checking Java version. Spring Boot 3 requires Java 17 or newer.
java -version
if errorlevel 1 goto nojava
for /f "tokens=3" %%v in ('java -version 2^>^&1 ^| findstr /i "version"') do set JAVAVER=%%v
echo.
echo If the version shown above is 1.8 or 8, install JDK 17 and update JAVA_HOME/PATH.
echo Download: https://adoptium.net/temurin/releases/?version=17
where mvn >nul 2>nul
if errorlevel 1 goto nomvn
mvn clean spring-boot:run
pause
exit /b
:nojava
echo Java is not installed or PATH is incorrect.
pause
exit /b 1
:nomvn
echo Maven is not installed or PATH is incorrect. Install Maven 3.9+ or use an IDE with Maven support.
pause
exit /b 1
