@echo off
setlocal
cd /d "%~dp0backend"
echo Spring Boot 3 requires JDK 17 or newer. Check the version below:
java -version
where mvn >nul 2>nul
if errorlevel 1 (echo Maven not found. Install Maven 3.9+ and add it to PATH. & pause & exit /b 1)
mvn clean package
if errorlevel 1 (echo Build failed. Confirm JAVA_HOME and PATH point to JDK 17+. & pause & exit /b 1)
echo Build successful: backend\target\crystal-saas-api-1.0.0.jar
pause
