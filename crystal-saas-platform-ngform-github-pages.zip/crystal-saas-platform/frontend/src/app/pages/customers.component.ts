import { Component, OnInit } from '@angular/core';
import { CommonModule, CurrencyPipe } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { ApiService } from '../core/api.service';
import { Customer, CustomerRequest } from '../core/models';

@Component({
  standalone: true, selector: 'app-customers', imports: [CommonModule, FormsModule, CurrencyPipe],
  template: `
  <section class="page-heading"><div><div class="eyebrow">RELATIONSHIP MANAGEMENT</div><h1>Customers</h1><p>Keep customer details organized and up to date.</p></div><button class="button primary" (click)="openCreate()">＋ New Customer</button></section>
  <div class="error-banner" *ngIf="error">{{error}}</div><div class="success-banner" *ngIf="success">{{success}}</div><div class="loading" *ngIf="loading">Loading customers…</div>
  <section class="panel"><div class="panel-heading"><div><h2>All customers <span class="count">{{totalElements}}</span></h2><p>Manage your customer directory and outstanding balances.</p></div><label class="search">⌕ <input placeholder="Search customers..." [(ngModel)]="search" (input)="onSearch()"></label></div>
  <div class="table-wrap"><table><thead><tr><th><input type="checkbox" [checked]="allSelected" (change)="selectAll($any($event.target).checked)"></th><th>Customer name</th><th>Company</th><th>Email address</th><th>Phone number</th><th>Receivables</th><th>Actions</th></tr></thead><tbody>
  <tr *ngFor="let customer of customers"><td><input type="checkbox" [checked]="selected.has(customer.id)" (change)="selectOne(customer.id,$any($event.target).checked)"></td><td><div class="customer-name"><span class="avatar">{{initials(customer.name)}}</span><b>{{customer.name}}</b></div></td><td>{{customer.company}}</td><td><a [href]="'mailto:'+customer.email">{{customer.email}}</a></td><td>{{customer.phone}}</td><td><b>{{customer.receivables | currency:'USD':'symbol':'1.2-2'}}</b></td><td><div class="actions"><button class="edit" (click)="openEdit(customer)" title="Edit customer">✎</button><button class="delete" (click)="remove(customer)" title="Delete customer">⌫</button></div></td></tr>
  <tr *ngIf="customers.length===0"><td colspan="7" class="empty">No customers found. Add a customer to get started.</td></tr>
  </tbody></table></div><div class="table-footer"><span>Showing <b>{{customers.length ? page*pageSize+1 : 0}}–{{MathMin((page+1)*pageSize,totalElements)}}</b> of <b>{{totalElements}}</b> customers <span *ngIf="selected.size"> · {{selected.size}} selected</span></span><div class="pagination"><button [disabled]="page===0" (click)="go(page-1)">← Previous</button><button class="page-number">{{page+1}}</button><button [disabled]="page+1>=totalPages" (click)="go(page+1)">Next →</button></div></div></section>
  <div class="modal-backdrop" *ngIf="modalOpen" (click)="closeModal()"><section class="modal" (click)="$event.stopPropagation()"><div class="modal-head"><div><div class="eyebrow">{{editingId ? 'CUSTOMER DETAILS' : 'NEW CONTACT'}}</div><h2>{{editingId ? 'Edit customer' : 'Add a new customer'}}</h2><p>Enter the contact details below.</p></div><button class="close" (click)="closeModal()">×</button></div>
    <form #customerForm="ngForm" (ngSubmit)="save(customerForm)" novalidate>
      <div class="form-grid"><label>Full name <span>*</span><input name="name" [(ngModel)]="form.name" required maxlength="100" placeholder="e.g. Alex Morgan"></label><label>Company <span>*</span><input name="company" [(ngModel)]="form.company" required maxlength="120" placeholder="Company name"></label><label class="wide">Email address <span>*</span><input name="email" [(ngModel)]="form.email" required email maxlength="160" placeholder="alex@company.com" #email="ngModel"><small class="validation" *ngIf="email.invalid && email.touched">Enter a valid email address.</small></label><label>Phone number <span>*</span><input name="phone" [(ngModel)]="form.phone" required pattern="^[0-9+() .-]{7,20}$" placeholder="+1 555 0100" #phone="ngModel"><small class="validation" *ngIf="phone.invalid && phone.touched">Enter a valid phone number (7–20 characters).</small></label><label>Receivables ($) <span>*</span><input name="receivables" type="number" [(ngModel)]="form.receivables" required min="0" step="0.01"></label></div>
      <div class="form-error" *ngIf="formError">{{formError}}</div><div class="modal-actions"><button type="button" class="button secondary" (click)="closeModal()">Cancel</button><button type="submit" class="button primary" [disabled]="saving">{{saving ? 'Saving…' : editingId ? 'Save changes' : 'Create customer'}}</button></div>
    </form></section></div>
  `,
  styles: [`
    :host{display:block}.page-heading{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:25px}.eyebrow{font-size:10px;font-weight:800;letter-spacing:1.4px;color:#6d60e8;margin-bottom:8px}h1{font-size:26px;letter-spacing:-.8px;margin:0}p{color:var(--muted);font-size:12px;margin:8px 0 0}.button{border:1px solid var(--border);background:var(--surface);color:var(--text);border-radius:8px;padding:10px 13px;font-size:11px;cursor:pointer}.button.primary{background:#6558e8;color:white;border-color:#6558e8}.button:disabled{opacity:.5;cursor:not-allowed}.panel{background:var(--surface);border:1px solid var(--border);border-radius:13px;padding:21px}.panel-heading{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;margin-bottom:22px}.panel h2{font-size:14px;margin:0}.panel-heading p{font-size:11px}.count{background:var(--page);border-radius:5px;padding:4px 6px;font-size:10px;color:var(--muted);margin-left:5px}.search{border:1px solid var(--border);border-radius:8px;padding:8px 10px;color:var(--muted);font-size:15px;display:flex;align-items:center;gap:7px}.search input{border:0;outline:0;background:transparent;color:var(--text);font-size:11px;width:170px}.table-wrap{overflow-x:auto}table{width:100%;border-collapse:collapse;white-space:nowrap}th{text-align:left;background:var(--page);color:var(--muted);font-size:10px;font-weight:600;padding:13px 10px}td{font-size:11px;padding:13px 10px;border-bottom:1px solid var(--border)}tbody tr:last-child td{border-bottom:0}input[type=checkbox]{accent-color:#6558e8;width:14px;height:14px;cursor:pointer}.customer-name{display:flex;align-items:center;gap:9px}.avatar{width:28px;height:28px;border-radius:50%;display:grid;place-items:center;background:#f0edff;color:#6558e8;font-size:9px;font-weight:800}.customer-name b{font-size:11px}td a{color:#6558e8;text-decoration:none}.actions{display:flex;gap:6px}.actions button{width:27px;height:27px;border-radius:7px;border:1px solid var(--border);background:var(--surface);color:var(--muted);cursor:pointer}.actions .edit:hover{color:#6558e8;border-color:#6558e8}.actions .delete:hover{color:#d85858;border-color:#d85858}.empty{text-align:center;padding:35px;color:var(--muted)}.table-footer{border-top:1px solid var(--border);padding-top:17px;margin-top:5px;display:flex;justify-content:space-between;align-items:center;gap:12px;color:var(--muted);font-size:10px}.table-footer b{color:var(--text)}.pagination{display:flex;gap:6px}.pagination button{background:var(--surface);border:1px solid var(--border);color:var(--text);border-radius:6px;padding:7px 10px;font-size:10px;cursor:pointer}.pagination button:disabled{opacity:.4;cursor:not-allowed}.pagination .page-number{background:#6558e8;color:white;border-color:#6558e8}.modal-backdrop{position:fixed;inset:0;background:#11182780;display:grid;place-items:center;z-index:50;padding:15px;overflow:auto}.modal{width:min(560px,100%);background:var(--surface);color:var(--text);border-radius:14px;padding:25px;box-shadow:0 20px 70px #0003;margin:auto}.modal-head{display:flex;justify-content:space-between;margin-bottom:23px}.modal-head h2{margin:0;font-size:19px}.modal-head p{margin-top:6px}.close{border:0;background:transparent;color:var(--muted);font-size:26px;cursor:pointer;align-self:flex-start}.form-grid{display:grid;grid-template-columns:1fr 1fr;gap:17px}.form-grid label{font-size:11px;font-weight:700;display:flex;flex-direction:column;gap:7px}.form-grid label span{color:#d85858;display:inline}.form-grid input{box-sizing:border-box;width:100%;border:1px solid var(--border);border-radius:8px;background:var(--page);color:var(--text);padding:11px;font-size:12px;outline:none}.form-grid input:focus{border-color:#6558e8}.form-grid .wide{grid-column:1/-1}.validation,.form-error{color:#d85858;font-size:10px;font-weight:400}.form-error{margin-top:12px}.modal-actions{display:flex;justify-content:flex-end;gap:9px;margin-top:25px}.success-banner,.error-banner,.loading{padding:12px;background:var(--surface);border:1px solid var(--border);border-radius:8px;margin-bottom:14px;font-size:12px}.error-banner{color:#c84d4d}.success-banner{color:#16875a}.loading{color:var(--muted)}
    @media(max-width:650px){.page-heading{align-items:flex-start;flex-direction:column}.page-heading h1{font-size:22px}.panel{padding:13px}.panel-heading{flex-direction:column}.search{width:100%;box-sizing:border-box}.search input{width:100%}.table-footer{align-items:flex-start;flex-direction:column}.pagination{width:100%;justify-content:flex-end}.form-grid{grid-template-columns:1fr}.form-grid .wide{grid-column:auto}.modal{padding:18px}}
  `]
})
export class CustomersComponent implements OnInit {
  MathMin = Math.min;
  customers: Customer[] = [];
  totalElements=0; totalPages=1; page=0; pageSize=10;
  search=''; loading=false; saving=false; error=''; success=''; formError='';
  modalOpen=false; editingId?:number; selected=new Set<number>(); allSelected=false;
  form:CustomerRequest=this.emptyForm();
  constructor(private api:ApiService){}
  ngOnInit():void{this.load();}
  emptyForm():CustomerRequest{return {name:'',company:'',email:'',phone:'',receivables:0};}
  load():void{
    this.loading=true;this.error='';
    this.api.customers(this.page,this.pageSize,this.search).subscribe({next:r=>{
      this.customers=r.content;this.totalElements=r.totalElements;this.totalPages=Math.max(1,r.totalPages);this.loading=false;
      this.allSelected=this.customers.length>0&&this.customers.every(c=>this.selected.has(c.id));
    },error:e=>{this.error=e.message;this.loading=false;}});
  }
  onSearch():void{this.page=0;this.load();}
  go(page:number):void{if(page<0||page>=this.totalPages)return;this.page=page;this.load();}
  initials(name:string):string{return name.split(' ').map(p=>p[0]).slice(0,2).join('').toUpperCase();}
  selectAll(checked:boolean):void{this.customers.forEach(c=>checked?this.selected.add(c.id):this.selected.delete(c.id));this.allSelected=checked;}
  selectOne(id:number,checked:boolean):void{checked?this.selected.add(id):this.selected.delete(id);this.allSelected=this.customers.length>0&&this.customers.every(c=>this.selected.has(c.id));}
  openCreate():void{this.editingId=undefined;this.form=this.emptyForm();this.formError='';this.modalOpen=true;}
  openEdit(customer:Customer):void{this.editingId=customer.id;this.form={name:customer.name,company:customer.company,email:customer.email,phone:customer.phone,receivables:customer.receivables};this.formError='';this.modalOpen=true;}
  closeModal():void{this.modalOpen=false;this.formError='';}
  save(formRef: NgForm):void{
    this.formError='';this.error='';
    if(!formRef.valid){this.formError='Please complete all required fields using a valid email, phone number, and non-negative receivables.';return;}
    this.saving=true;
    const request={...this.form,name:this.form.name.trim(),company:this.form.company.trim(),email:this.form.email.trim(),phone:this.form.phone.trim()};
    const action=this.editingId?this.api.updateCustomer(this.editingId,request):this.api.createCustomer(request);
    action.subscribe({next:()=>{this.saving=false;this.closeModal();this.success=this.editingId?'Customer updated successfully.':'Customer created successfully.';this.load();setTimeout(()=>this.success='',3000);},error:e=>{this.saving=false;this.formError=e.message;}});
  }
  remove(customer:Customer):void{
    if(!window.confirm(`Delete ${customer.name}? This action cannot be undone.`))return;
    this.api.deleteCustomer(customer.id).subscribe({next:()=>{this.success='Customer deleted successfully.';this.selected.delete(customer.id);if(this.customers.length===1&&this.page>0)this.page--;this.load();setTimeout(()=>this.success='',3000);},error:e=>this.error=e.message});
  }
}
