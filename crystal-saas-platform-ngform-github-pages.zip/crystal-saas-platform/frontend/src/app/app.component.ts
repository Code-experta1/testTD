import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink, RouterLinkActive, RouterOutlet } from '@angular/router';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [CommonModule, RouterLink, RouterLinkActive, RouterOutlet],
  template: `
  <div class="app-shell" [class.sidebar-collapsed]="collapsed" [class.dark-theme]="darkMode">
    <aside class="sidebar">
      <a class="brand" routerLink="/"><span class="brand-mark">C</span><span class="brand-name" *ngIf="!collapsed">crystal</span></a>
      <div class="workspace" *ngIf="!collapsed"><span class="workspace-avatar">C</span><span><b>Crystal Studio</b><small>Business workspace</small></span><span class="chevron">⌄</span></div>
      <div class="nav-label" *ngIf="!collapsed">WORKSPACE</div>
      <nav>
        <a routerLink="/" routerLinkActive="active" [routerLinkActiveOptions]="{exact:true}" [title]="collapsed ? 'Dashboard' : ''"><span class="nav-icon">◫</span><span *ngIf="!collapsed">Dashboard</span></a>
        <div class="nav-label" *ngIf="!collapsed">MANAGE</div>
        <a routerLink="/sales" routerLinkActive="active" [title]="collapsed ? 'Sales' : ''"><span class="nav-icon">↗</span><span *ngIf="!collapsed">Sales</span><span class="nav-count" *ngIf="!collapsed">4</span></a>
        <a href="javascript:void(0)" (click)="notice('Purchase module is not part of this assessment core.')" [title]="collapsed ? 'Purchase' : ''"><span class="nav-icon">▤</span><span *ngIf="!collapsed">Purchase</span><span class="nav-arrow" *ngIf="!collapsed">⌄</span></a>
        <a href="javascript:void(0)" (click)="notice('Items module is not part of this assessment core.')" [title]="collapsed ? 'Items' : ''"><span class="nav-icon">▦</span><span *ngIf="!collapsed">Items</span><span class="nav-arrow" *ngIf="!collapsed">⌄</span></a>
        <a routerLink="/customers" routerLinkActive="active" [title]="collapsed ? 'Customers' : ''"><span class="nav-icon">♙</span><span *ngIf="!collapsed">Customers</span></a>
        <div class="nav-label" *ngIf="!collapsed">PREFERENCES</div>
        <a href="javascript:void(0)" (click)="notice('Account preferences are demo-only.')" [title]="collapsed ? 'Account' : ''"><span class="nav-icon">⚙</span><span *ngIf="!collapsed">Account</span><span class="nav-arrow" *ngIf="!collapsed">⌄</span></a>
      </nav>
      <div class="sidebar-bottom">
        <button class="theme-button" (click)="darkMode = !darkMode" [title]="darkMode ? 'Switch to light mode' : 'Switch to dark mode'"><span>{{darkMode ? '☀' : '☾'}}</span><span *ngIf="!collapsed">{{darkMode ? 'Light mode' : 'Dark mode'}}</span><span class="toggle" *ngIf="!collapsed" [class.on]="darkMode"></span></button>
        <button class="collapse-button" (click)="collapsed = !collapsed"><span>{{collapsed ? '»' : '«'}}</span><span *ngIf="!collapsed">Collapse sidebar</span></button>
        <div class="profile" *ngIf="!collapsed"><div class="avatar">NS</div><div class="profile-text"><b>Naresh Sahoo</b><small>Workspace admin</small></div><span class="more">···</span></div>
        <div class="profile mini-profile" *ngIf="collapsed"><div class="avatar">NS</div></div>
      </div>
    </aside>
    <main class="main-area">
      <header class="topbar">
        <div class="breadcrumb"><span class="muted">Workspace</span><span>/</span><b>{{currentPage}}</b></div>
        <div class="top-actions">
          <label class="global-search"><span>⌕</span><input placeholder="Search anything..." [value]="searchText" (input)="searchText = $any($event.target).value"><kbd>⌘ K</kbd></label>
          <button class="icon-button" (click)="notice('You are all caught up!')" aria-label="Notifications">♧<i></i></button>
          <button class="refer-button" (click)="notice('Referral link copied soon — demo action.')">↗ <span>Refer &amp; Earn</span></button>
          <div class="top-avatar">NS</div>
        </div>
      </header>
      <div class="page-content"><router-outlet></router-outlet></div>
      <div class="toast" *ngIf="toast">{{toast}}</div>
    </main>
  </div>`,
  styles: [`
    :host{display:block;min-height:100vh}.app-shell{--sidebar-width:252px;min-height:100vh;background:var(--page);color:var(--text)}
    .sidebar{width:var(--sidebar-width);position:fixed;inset:0 auto 0 0;background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;padding:22px 14px;z-index:10;transition:width .2s}
    .sidebar-collapsed{--sidebar-width:76px}.brand{display:flex;align-items:center;gap:11px;padding:0 11px 25px;color:var(--text);text-decoration:none;font-size:24px;font-weight:800;letter-spacing:-1px}.brand-mark{width:32px;height:32px;display:grid;place-items:center;background:#5b50e8;color:#fff;border-radius:10px;font-size:21px;letter-spacing:0}.workspace{display:flex;align-items:center;gap:10px;padding:11px;border:1px solid var(--border);border-radius:12px;margin-bottom:25px}.workspace-avatar{background:#f1efff;color:#6558e8;border-radius:9px;width:32px;height:32px;display:grid;place-items:center;font-weight:800}.workspace b,.workspace small,.profile b,.profile small{display:block}.workspace b,.profile b{font-size:12px}.workspace small,.profile small{font-size:10px;color:var(--muted);margin-top:3px}.chevron{margin-left:auto;color:var(--muted)}.nav-label{font-size:10px;letter-spacing:1px;color:var(--muted);font-weight:700;padding:10px 12px}.sidebar nav{display:flex;flex-direction:column;gap:4px}.sidebar nav a{display:flex;align-items:center;gap:13px;padding:11px 12px;border-radius:9px;color:var(--muted);font-size:13px;text-decoration:none;white-space:nowrap}.sidebar nav a:hover{background:var(--page);color:var(--text)}.sidebar nav a.active{background:#f0efff;color:#5b50e8;font-weight:700}.nav-icon{font-size:18px;width:20px;text-align:center}.nav-count{margin-left:auto;background:#e8e6ff;color:#5b50e8;border-radius:6px;padding:2px 7px;font-size:10px}.nav-arrow{margin-left:auto}.sidebar-bottom{margin-top:auto}.theme-button,.collapse-button{width:100%;border:0;background:transparent;color:var(--muted);display:flex;align-items:center;gap:12px;padding:12px;border-radius:9px;text-align:left;font-size:12px;cursor:pointer}.theme-button:hover,.collapse-button:hover{background:var(--page)}.toggle{margin-left:auto;width:28px;height:16px;border-radius:20px;background:#ddd;position:relative}.toggle:after{content:'';position:absolute;left:2px;top:2px;width:12px;height:12px;background:#fff;border-radius:50%;transition:.2s}.toggle.on{background:#6157e8}.toggle.on:after{left:14px}.profile{border-top:1px solid var(--border);margin-top:12px;padding:18px 6px 0;display:flex;align-items:center;gap:9px}.avatar,.top-avatar{display:grid;place-items:center;border-radius:50%;background:#e6dcce;color:#614c3d;font-weight:800;font-size:11px;width:32px;height:32px;flex-shrink:0}.profile-text{min-width:0}.more{margin-left:auto}.main-area{margin-left:var(--sidebar-width);min-height:100vh;transition:margin-left .2s}.topbar{height:76px;background:var(--surface);border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;padding:0 34px;gap:18px}.breadcrumb{display:flex;gap:12px;align-items:center;font-size:12px}.breadcrumb .muted{color:var(--muted)}.top-actions{display:flex;align-items:center;gap:18px}.global-search{height:36px;width:245px;border:1px solid var(--border);border-radius:9px;display:flex;align-items:center;gap:8px;padding:0 9px;color:var(--muted)}.global-search input{width:100%;border:0;outline:0;background:transparent;color:var(--text);font:inherit;font-size:11px}.global-search kbd{white-space:nowrap;font-size:9px;background:var(--page);border:1px solid var(--border);border-radius:4px;padding:3px}.icon-button{border:0;background:transparent;color:var(--muted);font-size:20px;position:relative;cursor:pointer}.icon-button i{position:absolute;width:5px;height:5px;background:#f97373;border-radius:50%;right:1px;top:3px}.refer-button{border:1px solid #dcd8ff;background:#f5f3ff;color:#5b50e8;border-radius:8px;padding:9px 12px;font-size:11px;font-weight:700;cursor:pointer}.top-avatar{width:30px;height:30px}.page-content{padding:30px 34px 45px;max-width:1600px;margin:auto}.toast{position:fixed;right:24px;bottom:24px;background:#202033;color:#fff;padding:13px 18px;border-radius:10px;box-shadow:0 8px 30px #0002;z-index:30;font-size:13px}.dark-theme{--page:#121522;--surface:#1b2030;--text:#f1f3f9;--muted:#a1a8bb;--border:#30374a}.dark-theme .sidebar nav a.active{background:#302b55;color:#c4beff}.dark-theme .refer-button{background:#302b55;border-color:#454071}.dark-theme .workspace-avatar{background:#302b55;color:#c4beff}.dark-theme .nav-count{background:#302b55;color:#c4beff}
    @media(max-width:900px){.topbar{padding:0 20px}.page-content{padding:24px 20px}.global-search{width:180px}.refer-button span{display:none}.top-actions{gap:10px}}
    @media(max-width:650px){.app-shell{--sidebar-width:64px}.sidebar{padding:18px 8px}.brand{padding:0 8px 24px}.brand-name,.workspace,.nav-label,.sidebar nav a span:not(.nav-icon),.theme-button span:not(:first-child),.collapse-button span:not(:first-child),.profile-text,.more{display:none!important}.sidebar nav a{justify-content:center;padding:12px 8px}.theme-button,.collapse-button{justify-content:center;padding:12px 8px}.profile{justify-content:center;padding-top:15px}.topbar{height:auto;min-height:66px;padding:12px 14px;flex-wrap:wrap}.breadcrumb{display:none}.top-actions{width:100%;justify-content:space-between}.global-search{width:min(55%,240px)}.page-content{padding:18px 13px 30px}}
  `]
})
export class AppComponent {
  collapsed = false;
  darkMode = false;
  searchText = '';
  toast = '';
  currentPage = 'Dashboard';
  private toastTimer?: ReturnType<typeof setTimeout>;
  constructor() {
    window.addEventListener('popstate', () => this.syncPage());
    setTimeout(() => this.syncPage(), 0);
  }
  syncPage(): void {
    const path = window.location.pathname;
    this.currentPage = path.includes('customers') ? 'Customers' : path.includes('sales') ? 'Sales' : 'Dashboard';
  }
  notice(message: string): void {
    this.toast = message;
    if (this.toastTimer) clearTimeout(this.toastTimer);
    this.toastTimer = setTimeout(() => this.toast = '', 2600);
  }
}
