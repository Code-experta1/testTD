import { HttpErrorResponse, HttpInterceptorFn } from '@angular/common/http';
import { catchError, throwError } from 'rxjs';

export const apiErrorInterceptor: HttpInterceptorFn = (request, next) =>
  next(request).pipe(
    catchError((error: HttpErrorResponse) => {
      let message = 'Something went wrong. Please try again.';
      if (error.status === 0) message = 'Cannot reach the API. Check that Spring Boot is running on port 8080.';
      else if (error.status === 400) message = 'Please check the information you entered.';
      else if (error.status === 404) message = 'The requested record was not found.';
      else if (error.status === 409) message = 'That email address is already in use.';
      else if (error.status >= 500) message = 'The server encountered an error.';
      return throwError(() => new Error(message));
    })
  );
