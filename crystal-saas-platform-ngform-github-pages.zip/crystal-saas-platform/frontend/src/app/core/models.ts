export interface Customer {
  id: number;
  name: string;
  company: string;
  email: string;
  phone: string;
  receivables: number;
}
export interface CustomerRequest {
  name: string;
  company: string;
  email: string;
  phone: string;
  receivables: number;
}
export interface PageResponse<T> {
  content: T[];
  totalElements: number;
  totalPages: number;
  number: number;
  size: number;
}
export interface DashboardSummary {
  totalSale: number;
  saleChange: number;
  activeOrders: number;
  orderChange: number;
  lowStockItems: number;
  stockChange: number;
  period: string;
}
export interface RevenuePoint { day: string; online: number; offline: number; }
export interface SatisfactionPoint { label: string; lastMonth: number; thisMonth: number; }
export interface SalesSummary {
  totalSales: number; orders: number; completed: number; pending: number; averageOrder: number;
  salesChange: number; ordersChange: number; completedChange: number; pendingChange: number; averageChange: number;
}
export interface SaleReport {
  id: number; invoiceNumber: string; customerName: string; date: string;
  amount: number; channel: string; status: string;
}
