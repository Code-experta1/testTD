import { environment } from '../../environments/environment';
import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Customer, CustomerRequest, DashboardSummary, PageResponse, RevenuePoint, SatisfactionPoint, SaleReport, SalesSummary } from './models';

@Injectable({ providedIn: 'root' })
export class ApiService {
  private readonly base = environment.apiUrl;
  constructor(private http: HttpClient) {}

  dashboardSummary(period: string): Observable<DashboardSummary> {
    return this.http.get<DashboardSummary>(`${this.base}/dashboard/summary`, { params: { period } });
  }
  revenue(period: string): Observable<RevenuePoint[]> {
    return this.http.get<RevenuePoint[]>(`${this.base}/dashboard/revenue`, { params: { period } });
  }
  satisfaction(period: string): Observable<SatisfactionPoint[]> {
    return this.http.get<SatisfactionPoint[]>(`${this.base}/dashboard/satisfaction`, { params: { period } });
  }
  salesSummary(period: string, month: string): Observable<SalesSummary> {
    let params = new HttpParams().set('period', period);
    if (month) params = params.set('month', month);
    return this.http.get<SalesSummary>(`${this.base}/sales/summary`, { params });
  }
  salesReports(page: number, size: number, period: string, month: string): Observable<PageResponse<SaleReport>> {
    let params = new HttpParams().set('page', page).set('size', size).set('period', period);
    if (month) params = params.set('month', month);
    return this.http.get<PageResponse<SaleReport>>(`${this.base}/sales/reports`, { params });
  }
  customers(page: number, size: number, search: string): Observable<PageResponse<Customer>> {
    return this.http.get<PageResponse<Customer>>(`${this.base}/customers`, { params: { page, size, search } });
  }
  customer(id: number): Observable<Customer> { return this.http.get<Customer>(`${this.base}/customers/${id}`); }
  createCustomer(payload: CustomerRequest): Observable<Customer> { return this.http.post<Customer>(`${this.base}/customers`, payload); }
  updateCustomer(id: number, payload: CustomerRequest): Observable<Customer> { return this.http.put<Customer>(`${this.base}/customers/${id}`, payload); }
  deleteCustomer(id: number): Observable<void> { return this.http.delete<void>(`${this.base}/customers/${id}`); }
}
