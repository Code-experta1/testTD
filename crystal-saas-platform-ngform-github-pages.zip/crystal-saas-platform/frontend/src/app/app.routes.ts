import { Routes } from '@angular/router';
import { DashboardComponent } from './pages/dashboard.component';
import { SalesComponent } from './pages/sales.component';
import { CustomersComponent } from './pages/customers.component';

export const routes: Routes = [
  { path: '', component: DashboardComponent, title: 'Dashboard | Crystal' },
  { path: 'sales', component: SalesComponent, title: 'Sales | Crystal' },
  { path: 'customers', component: CustomersComponent, title: 'Customers | Crystal' },
  { path: '**', redirectTo: '' }
];
