@echo off
setlocal
cd /d "%~dp0frontend"
node --version
npm --version
if not exist node_modules (npm install)
if errorlevel 1 (pause & exit /b 1)
npm run build:pages
pause
