# Crystal SaaS Platform — Angular + Spring Boot

## Important: fix for the Maven error you shared

Your error says `class file has wrong version 61.0, should be 52.0`. Version 61 means Java 17 bytecode; version 52 means the build is running on Java 8. This project uses Spring Boot 3.3.5, which requires **JDK 17 or newer**. Installing dependencies again will not fix a Java-version mismatch.

1. Install JDK 17: https://adoptium.net/temurin/releases/?version=17
2. Set `JAVA_HOME` to the JDK 17 installation folder and put `%JAVA_HOME%\bin` before older Java entries in `Path`.
3. Close and reopen PowerShell, then run `java -version` and make sure it reports 17 or newer. Also run `where java` to check that an old Java 8 installation is not first.
4. Install Maven 3.9+ if `mvn -version` is not recognized. Confirm `mvn -version` also reports Java 17+.
5. In this project, run `cd backend` then `mvn clean package`. Or double-click `BUILD-BACKEND-WINDOWS.bat` from the project root.

## Run locally

### Backend

- Requires JDK 17+ and Maven 3.9+.
- From `backend`: `mvn spring-boot:run`
- API base URL: `http://localhost:8080/api`
- Health check: `http://localhost:8080/api/dashboard/summary`
- H2 is in-memory, so demo data resets when the backend restarts.

### Frontend

- Requires Node.js 20 (recommended) and npm.
- From `frontend`: `npm install`, then `npm start`.
- Open `http://localhost:4200`.
- The customer form uses Angular `NgForm`; its `valid` property can be `boolean | null`, so the previous `{valid:boolean}` parameter type caused a TypeScript error. It has been corrected to `save(formRef: NgForm)`.

## Publish the frontend on GitHub Pages

GitHub Pages can host the Angular static frontend only. It does **not** run the Spring Boot API. To make customer/sales/dashboard data work online, deploy the backend separately (the included `backend/render.yaml` is configured for Render), then set the GitHub repository Actions variable/secret `API_BASE_URL` to the deployed API base URL, ending in `/api` (example format: `https://your-service.onrender.com/api`). Do not use the example URL literally.

1. Extract this ZIP on your PC.
2. Open the extracted `crystal-saas-platform` folder. Upload the **contents** of this folder to the root of your GitHub repository, not the ZIP file itself. Include `.github`, `frontend`, and `backend`. Do not upload `node_modules` or `backend/target`.
3. Use the repository `Code-experta1/MyProjectAssignmentNareshSahooProject` or change the `--base-href` in `frontend/package.json` and workflow to match your actual repository name.
4. On GitHub, open **Settings → Secrets and variables → Actions → Secrets** and create secret `API_BASE_URL` with the actual deployed backend API URL ending `/api`. The included workflow reads this value as a repository secret.
5. Open **Settings → Pages** and set **Build and deployment → Source** to **GitHub Actions**.
6. Open the **Actions** tab, select **Deploy Angular frontend to GitHub Pages**, and inspect the latest run. Wait until both build and deploy jobs succeed.
7. Your site URL for the repository above is `https://code-experta1.github.io/MyProjectAssignmentNareshSahooProject/`.

If the repository's default branch is `main`, the workflow runs on pushes to `main`; `master`, `crystal-ui-v2`, and `crystal-saas-v2` are also included. If you use another branch, add its name to `.github/workflows/deploy-pages.yml` or merge it into `main`.

## What is included

- Angular 17 responsive UI with Dashboard, Sales and Customers pages.
- Spring Boot 3 REST API with H2 demo database.
- GitHub Actions workflow for GitHub Pages.
- Render configuration for separate backend deployment.
- Windows helper scripts for build/run.

## Troubleshooting

- `wrong version 61.0, should be 52.0`: Maven is using Java 8; switch `JAVA_HOME`/`Path` to JDK 17+.
- GitHub Pages shows a blank page: verify repository-name base href and that the Actions deployment succeeded.
- UI loads but API calls fail online: backend is not deployed, the API URL is still a placeholder, or CORS/API URL is incorrect.
