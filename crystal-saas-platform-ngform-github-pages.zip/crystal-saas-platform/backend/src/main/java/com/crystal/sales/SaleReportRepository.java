package com.crystal.sales;

import java.time.LocalDate;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SaleReportRepository extends JpaRepository<SaleReport, Long> {
    Page<SaleReport> findByDateBetween(LocalDate start, LocalDate end, Pageable pageable);
}
