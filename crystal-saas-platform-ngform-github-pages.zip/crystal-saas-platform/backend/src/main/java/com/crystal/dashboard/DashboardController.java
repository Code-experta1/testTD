package com.crystal.dashboard;

import java.time.LocalDate;
import java.util.*;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/dashboard")
public class DashboardController {
    @GetMapping("/summary") public Map<String,Object> summary(@RequestParam(defaultValue="week") String period) {
        Map<String,Object> data = new LinkedHashMap<>();
        data.put("totalSale", 48250); data.put("saleChange", 12.8);
        data.put("activeOrders", 128); data.put("orderChange", 6.4);
        data.put("lowStockItems", 9); data.put("stockChange", -3.2);
        data.put("period", period); return data;
    }
    @GetMapping("/revenue") public List<Map<String,Object>> revenue(@RequestParam(defaultValue="week") String period) {
        String[] days={"Mon","Tue","Wed","Thu","Fri","Sat","Sun"};
        int[][] values={{3200,2100},{4100,2600},{3600,2900},{5100,3300},{4600,3800},{6200,4100},{5400,3600}};
        List<Map<String,Object>> result=new ArrayList<>();
        for(int i=0;i<days.length;i++){Map<String,Object> row=new LinkedHashMap<>(); row.put("day",days[i]); row.put("online",values[i][0]); row.put("offline",values[i][1]); result.add(row);}
        return result;
    }
    @GetMapping("/satisfaction") public List<Map<String,Object>> satisfaction(@RequestParam(defaultValue="week") String period) {
        String[] labels={"Week 1","Week 2","Week 3","Week 4"};
        int[] last={68,72,70,76}, current={72,75,81,86};
        List<Map<String,Object>> result=new ArrayList<>();
        for(int i=0;i<labels.length;i++){Map<String,Object> row=new LinkedHashMap<>();row.put("label",labels[i]);row.put("lastMonth",last[i]);row.put("thisMonth",current[i]);result.add(row);}
        return result;
    }
}
