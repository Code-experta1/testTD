package com.crystal.customer;

import org.springframework.data.domain.*;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

@Service
@Transactional
public class CustomerService {
    private final CustomerRepository repository;
    public CustomerService(CustomerRepository repository) { this.repository = repository; }

    @Transactional(readOnly = true)
    public Page<Customer> findAll(String search, int page, int size) {
        Pageable pageable = PageRequest.of(Math.max(0, page), Math.min(Math.max(1, size), 100), Sort.by("name").ascending());
        if (search == null || search.isBlank()) return repository.findAll(pageable);
        String q = search.trim();
        return repository.findByNameContainingIgnoreCaseOrCompanyContainingIgnoreCaseOrEmailContainingIgnoreCase(q, q, q, pageable);
    }
    @Transactional(readOnly = true)
    public Customer findById(Long id) {
        return repository.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Customer not found"));
    }
    public Customer create(CustomerRequest request) {
        if (repository.existsByEmailIgnoreCase(request.getEmail())) throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already exists");
        return repository.save(copy(new Customer(), request));
    }
    public Customer update(Long id, CustomerRequest request) {
        Customer existing = findById(id);
        if (!existing.getEmail().equalsIgnoreCase(request.getEmail()) && repository.existsByEmailIgnoreCase(request.getEmail()))
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Email already exists");
        return repository.save(copy(existing, request));
    }
    public void delete(Long id) { repository.delete(findById(id)); }
    private Customer copy(Customer customer, CustomerRequest request) {
        customer.setName(request.getName().trim()); customer.setCompany(request.getCompany().trim());
        customer.setEmail(request.getEmail().trim().toLowerCase()); customer.setPhone(request.getPhone().trim());
        customer.setReceivables(request.getReceivables()); return customer;
    }
}
