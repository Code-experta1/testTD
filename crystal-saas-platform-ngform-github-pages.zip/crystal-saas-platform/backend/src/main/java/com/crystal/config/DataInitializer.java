package com.crystal.config;

import com.crystal.customer.*;
import com.crystal.sales.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    private final CustomerRepository customers;
    private final SaleReportRepository sales;
    public DataInitializer(CustomerRepository customers, SaleReportRepository sales) { this.customers=customers; this.sales=sales; }

    @Override public void run(String... args) {
        if (customers.count()==0) {
            customers.saveAll(List.of(
                new Customer("Olivia Rhye","Acme Inc.","olivia@acme.example","+1 555 0101",new BigDecimal("1240.00")),
                new Customer("Phoenix Baker","Bright Studio","phoenix@bright.example","+1 555 0102",new BigDecimal("680.50")),
                new Customer("Lana Steiner","Northstar Co.","lana@northstar.example","+1 555 0103",new BigDecimal("0.00")),
                new Customer("Demi Wilkinson","Orbit Labs","demi@orbit.example","+1 555 0104",new BigDecimal("2150.00")),
                new Customer("Candice Wu","Pixel House","candice@pixel.example","+1 555 0105",new BigDecimal("430.00")),
                new Customer("Natali Craig","Vertex Group","natali@vertex.example","+1 555 0106",new BigDecimal("125.00")),
                new Customer("Drew Cano","Summit Works","drew@summit.example","+1 555 0107",new BigDecimal("970.00")),
                new Customer("Orlando Diggs","Evergreen","orlando@evergreen.example","+1 555 0108",new BigDecimal("0.00")),
                new Customer("Andi Lane","Mono Studio","andi@mono.example","+1 555 0109",new BigDecimal("340.00")),
                new Customer("Kate Morrison","Bluebird Ltd.","kate@bluebird.example","+1 555 0110",new BigDecimal("820.00")),
                new Customer("John Smith","Maple Systems","john@maple.example","+1 555 0111",new BigDecimal("115.00")),
                new Customer("Sarah Chen","Cloud Nine","sarah@cloudnine.example","+1 555 0112",new BigDecimal("540.00"))
            ));
        }
        if (sales.count()==0) {
            String[] names={"Olivia Rhye","Phoenix Baker","Lana Steiner","Demi Wilkinson","Candice Wu","Natali Craig","Drew Cano","Orlando Diggs","Andi Lane","Kate Morrison","John Smith","Sarah Chen","Olivia Rhye"};
            String[] status={"Completed","Completed","Pending","Completed","Cancelled","Pending","Completed","Completed","Pending","Completed","Completed","Pending","Completed"};
            String[] channel={"Online","Offline","Online","Online","Offline","Online","Offline","Online","Offline","Online","Offline","Online","Online"};
            for(int i=0;i<names.length;i++) {
                sales.save(new SaleReport(String.format("INV-%04d",1001+i), names[i], LocalDate.now().minusDays(i),
                    new BigDecimal(String.valueOf(180+i*73.5)), channel[i], status[i]));
            }
        }
    }
}
