package com.crystal.customer;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public class CustomerRequest {
    @NotBlank @Size(max = 100) private String name;
    @NotBlank @Size(max = 120) private String company;
    @NotBlank @Email @Size(max = 160) private String email;
    @NotBlank @Pattern(regexp = "^[0-9+() .-]{7,20}$", message = "Enter a valid phone number") private String phone;
    @NotNull @DecimalMin(value = "0.0", inclusive = true) private BigDecimal receivables = BigDecimal.ZERO;

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCompany() { return company; }
    public void setCompany(String company) { this.company = company; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public BigDecimal getReceivables() { return receivables; }
    public void setReceivables(BigDecimal receivables) { this.receivables = receivables; }
}
