package com.crystal.sales;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.*;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;

@Service
public class SalesService {
    private final SaleReportRepository repository;
    public SalesService(SaleReportRepository repository) { this.repository = repository; }

    public Map<String,Object> summary(String period, String month) {
        List<SaleReport> all = filtered(period, month);
        BigDecimal total = all.stream().map(SaleReport::getAmount).reduce(BigDecimal.ZERO, BigDecimal::add);
        long completed = all.stream().filter(s -> "Completed".equalsIgnoreCase(s.getStatus())).count();
        long pending = all.stream().filter(s -> "Pending".equalsIgnoreCase(s.getStatus())).count();
        Map<String,Object> out = new LinkedHashMap<>();
        out.put("totalSales", total); out.put("orders", all.size()); out.put("completed", completed);
        out.put("pending", pending); out.put("averageOrder", all.isEmpty()? BigDecimal.ZERO : total.divide(BigDecimal.valueOf(all.size()), 2, java.math.RoundingMode.HALF_UP));
        out.put("salesChange", 12.4); out.put("ordersChange", 8.2); out.put("completedChange", 5.1);
        out.put("pendingChange", -2.3); out.put("averageChange", 4.7);
        return out;
    }
    public Page<SaleReport> reports(int page, int size, String period, String month) {
        Pageable pageable = PageRequest.of(Math.max(0,page), Math.min(Math.max(1,size),100), Sort.by("date").descending());
        LocalDate today = LocalDate.now();
        LocalDate start = today.minusDays(6), end = today;
        if ("day".equalsIgnoreCase(period)) start = end = today;
        else if (month != null && month.matches("\\d{4}-\\d{2}")) {
            YearMonth ym = YearMonth.parse(month); start = ym.atDay(1); end = ym.atEndOfMonth();
        } else if ("all".equalsIgnoreCase(period)) { return repository.findAll(pageable); }
        return repository.findByDateBetween(start, end, pageable);
    }
    private List<SaleReport> filtered(String period, String month) {
        if (month != null && month.matches("\\d{4}-\\d{2}")) {
            YearMonth ym=YearMonth.parse(month); return repository.findByDateBetween(ym.atDay(1),ym.atEndOfMonth(),Pageable.unpaged()).getContent();
        }
        LocalDate end=LocalDate.now(), start="day".equalsIgnoreCase(period)?end:end.minusDays(6);
        if ("all".equalsIgnoreCase(period)) return repository.findAll();
        return repository.findByDateBetween(start,end,Pageable.unpaged()).getContent();
    }
}
