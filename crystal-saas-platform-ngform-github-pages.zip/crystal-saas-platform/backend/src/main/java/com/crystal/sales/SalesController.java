package com.crystal.sales;

import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/sales")
public class SalesController {
    private final SalesService service;
    public SalesController(SalesService service) { this.service = service; }
    @GetMapping("/summary") public Map<String,Object> summary(@RequestParam(defaultValue="week") String period, @RequestParam(required=false) String month) {
        return service.summary(period, month);
    }
    @GetMapping("/reports") public Page<SaleReport> reports(@RequestParam(defaultValue="0") int page,
            @RequestParam(defaultValue="10") int size, @RequestParam(defaultValue="all") String period,
            @RequestParam(required=false) String month) { return service.reports(page,size,period,month); }
}
