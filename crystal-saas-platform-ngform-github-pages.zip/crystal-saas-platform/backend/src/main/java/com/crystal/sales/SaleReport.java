package com.crystal.sales;

import jakarta.persistence.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "sale_reports")
public class SaleReport {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long id;
    @Column(nullable = false) private String invoiceNumber;
    @Column(nullable = false) private String customerName;
    @Column(nullable = false) private LocalDate date;
    @Column(nullable = false, precision = 12, scale = 2) private BigDecimal amount;
    @Column(nullable = false) private String channel;
    @Column(nullable = false) private String status;

    public SaleReport() {}
    public SaleReport(String invoiceNumber, String customerName, LocalDate date, BigDecimal amount, String channel, String status) {
        this.invoiceNumber=invoiceNumber; this.customerName=customerName; this.date=date; this.amount=amount; this.channel=channel; this.status=status;
    }
    public Long getId(){return id;} public String getInvoiceNumber(){return invoiceNumber;}
    public String getCustomerName(){return customerName;} public LocalDate getDate(){return date;}
    public BigDecimal getAmount(){return amount;} public String getChannel(){return channel;} public String getStatus(){return status;}
}
